"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_home_home_module_ts"],{

/***/ 429:
/*!***********************************************************************************************************************************************!*\
  !*** ./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/home/home.page.html ***!
  \***********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header no-shadow>\r\n  <ion-toolbar>\r\n    <ion-label>PROJECT CONNECT <span class=\"daily-chk\">DAILY CHECK</span></ion-label>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content no-bounce >\r\n  \r\n     <!--  <img [src]=\"slide.image\" class=\"slide-image\" /> -->\r\n     <div class=\"welcomebg1\">\r\n     <div class=\"top-layout\"> \r\n      <div class=\"welcometxt1\" >Welcome to Project Connect <span class=\"daily-chk\">Daily Check</span></div>\r\n      <div class=\"welcometxt2\">Help your school get better connectivity. Share your school's internet status with Project Connectivity everyday.</div>\r\n      </div>\r\n      <div class=\"bottom-layout\">\r\n      <ion-button color=\"primary\" block [routerLink]=\"['/searchschool']\" class=\"dailycheck_btn\">SET UP DAILY CHECK <span class=\"rightArr\">&rsaquo;</span></ion-button>\r\n      <div class=\"learnmore\">LEARN MORE ABOUT PROJECT CONNECT <span class=\"rightArr\">&rsaquo;</span></div>     \r\n    </div>\r\n  </div>\r\n</ion-content>\r\n");

/***/ }),

/***/ 3245:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 8763);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], HomePageRoutingModule);



/***/ }),

/***/ 8890:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8058);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 8763);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 3245);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 8763:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _C_Users_ezmonka_apps_unicef_pdca_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./home.page.html */ 429);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 968);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);




let HomePage = class HomePage {
    constructor() { }
};
HomePage.ctorParameters = () => [];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-home',
        template: _C_Users_ezmonka_apps_unicef_pdca_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 968:
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/***/ ((module) => {

module.exports = "ion-header {\n  background-color: #000000 !important;\n  height: 70px;\n}\n\n.welcomebg1 {\n  padding: 0px 30px !important;\n  background: url('welcome_bg.jpg') !important;\n  background-size: 100% 100%;\n  position: fixed;\n  left: 0;\n  /* Preserve aspet ratio */\n  min-width: 100%;\n  min-height: 100%;\n}\n\n.welcometxt1 {\n  font-size: 45px;\n  padding-top: 24px;\n  color: #ffffff;\n}\n\n.welcometxt2 {\n  font-size: 26px;\n  padding-top: 20px;\n  color: #ffffff;\n}\n\nion-content ion-label {\n  font-size: 15px;\n}\n\n.learnmore {\n  font-family: Cabin;\n  font-size: 12px;\n  padding: 0px 30px;\n  padding-top: 10px;\n  color: #ffffff;\n}\n\n.learnmore span {\n  font-size: 24px;\n  padding-left: 5px;\n}\n\ndiv.slide-title {\n  margin-top: 2.8rem;\n  padding: 0 20px;\n  text-align: left;\n  font-size: 45px !important;\n  line-height: 44px;\n}\n\n.dailycheck_btn {\n  width: 100%;\n}\n\n.slide-image {\n  max-height: 40%;\n  max-width: 60%;\n  margin: 36px 0;\n}\n\n.bottom-layout {\n  position: absolute;\n  bottom: 100px;\n  padding: 0px 20px;\n  width: 100%;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usb0NBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBQ0E7RUFFQyw0QkFBQTtFQUNBLDRDQUFBO0VBQ0EsMEJBQUE7RUFDQSxlQUFBO0VBQ0EsT0FBQTtFQUNBLHlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBQ0Q7O0FBQ0E7RUFFRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBRUY7O0FBQ0U7RUFDRSxlQUFBO0FBRUo7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQUVGOztBQURFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBR0o7O0FBQUE7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLDBCQUFBO0VBQ0EsaUJBQUE7QUFHSjs7QUFEQTtFQUNFLFdBQUE7QUFJRjs7QUFGQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtBQUtGOztBQUhBO0VBQ0Usa0JBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUFNRiIsImZpbGUiOiJob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJ7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDAwMCAhaW1wb3J0YW50O1xyXG4gIGhlaWdodDogNzBweDtcclxufVxyXG4ud2VsY29tZWJnMXtcclxuICBcclxuIHBhZGRpbmc6IDBweCAzMHB4ICFpbXBvcnRhbnQ7XHJcbiBiYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2VzL3dlbGNvbWVfYmcuanBnXCIpICFpbXBvcnRhbnQ7XHJcbiBiYWNrZ3JvdW5kLXNpemU6IDEwMCUgMTAwJTtcclxuIHBvc2l0aW9uOiBmaXhlZDsgIFxyXG4gbGVmdDogMDsgXHJcbiAvKiBQcmVzZXJ2ZSBhc3BldCByYXRpbyAqL1xyXG4gbWluLXdpZHRoOiAxMDAlO1xyXG4gbWluLWhlaWdodDogMTAwJTtcclxufVxyXG4ud2VsY29tZXR4dDF7XHJcbiBcclxuICBmb250LXNpemU6IDQ1cHg7IFxyXG4gIHBhZGRpbmctdG9wOiAyNHB4O1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG59XHJcbi53ZWxjb21ldHh0MntcclxuICBmb250LXNpemU6IDI2cHg7ICBcclxuICBwYWRkaW5nLXRvcDogMjBweDtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxufVxyXG5pb24tY29udGVudHtcclxuICBpb24tbGFiZWx7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgfVxyXG59XHJcbi5sZWFybm1vcmV7XHJcbiAgZm9udC1mYW1pbHk6Q2FiaW47XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG4gIHBhZGRpbmc6IDBweCAzMHB4O1xyXG4gIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG4gIHNwYW57XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICB9XHJcbn1cclxuZGl2LnNsaWRlLXRpdGxlIHtcclxuICAgIG1hcmdpbi10b3A6IDIuOHJlbTtcclxuICAgIHBhZGRpbmc6IDAgMjBweDtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBmb250LXNpemU6IDQ1cHggIWltcG9ydGFudDsgICAgXHJcbiAgICBsaW5lLWhlaWdodDogNDRweDtcclxuICB9XHJcbi5kYWlseWNoZWNrX2J0bntcclxuICB3aWR0aDoxMDAlO1xyXG59XHJcbi5zbGlkZS1pbWFnZSB7XHJcbiAgbWF4LWhlaWdodDogNDAlO1xyXG4gIG1heC13aWR0aDogNjAlO1xyXG4gIG1hcmdpbjogMzZweCAwO1xyXG59XHJcbi5ib3R0b20tbGF5b3V0e1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTsgICBcclxuICBib3R0b206MTAwcHg7XHJcbiAgcGFkZGluZzogMHB4IDIwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG5cclxuXHJcbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map